# -*- coding: utf-8 -*-
"""
Created on Mon Nov  6 16:00:53 2023

@author: hp
"""

import pandas as pd
import pharma_final_2






